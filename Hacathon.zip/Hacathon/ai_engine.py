"""
AI Engine for FinGenius - Handles LLM interactions, RAG, and financial analysis
"""
import openai
import google.generativeai as genai
import pandas as pd
import numpy as np
import json
import re
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import chromadb
from chromadb.config import Settings

from config import OPENAI_API_KEY, GOOGLE_API_KEY, DEFAULT_AI_MODEL, SPENDING_CATEGORIES

class AIEngine:
    def __init__(self, model_name: str = DEFAULT_AI_MODEL):
        self.model_name = model_name
        self.client = None
        self.vector_db = None
        
        # Initialize AI client based on model
        if "gpt" in model_name.lower():
            openai.api_key = OPENAI_API_KEY
            self.client = openai.OpenAI(api_key=OPENAI_API_KEY)
        elif "gemini" in model_name.lower():
            genai.configure(api_key=GOOGLE_API_KEY)
            self.client = genai.GenerativeModel('gemini-pro')
        
        # Initialize vector database for RAG
        self._init_vector_db()
        
    def _init_vector_db(self):
        """Initialize ChromaDB for vector storage"""
        try:
            self.vector_db = chromadb.Client(Settings(anonymized_telemetry=False))
            self.collection = self.vector_db.create_collection(
                name="financial_knowledge",
                metadata={"description": "Financial knowledge base for RAG"}
            )
            self._populate_knowledge_base()
        except Exception as e:
            print(f"Vector DB initialization failed: {e}")
            self.vector_db = None
    
    def _populate_knowledge_base(self):
        """Populate the knowledge base with financial information"""
        if not self.vector_db:
            return
            
        financial_knowledge = [
            {
                "content": "Compound interest is interest calculated on the initial principal and also on the accumulated interest of previous periods. It's calculated using the formula: A = P(1 + r/n)^(nt)",
                "metadata": {"topic": "compound_interest", "category": "investing"}
            },
            {
                "content": "The 50/30/20 rule is a budgeting guideline: 50% of income for needs, 30% for wants, and 20% for savings and debt repayment.",
                "metadata": {"topic": "budgeting", "category": "personal_finance"}
            },
            {
                "content": "An emergency fund should cover 3-6 months of living expenses and be kept in a high-yield savings account for easy access.",
                "metadata": {"topic": "emergency_fund", "category": "savings"}
            },
            {
                "content": "Credit score ranges: Excellent (750+), Good (700-749), Fair (650-699), Poor (600-649), Very Poor (below 600).",
                "metadata": {"topic": "credit_score", "category": "credit"}
            },
            {
                "content": "Debt-to-income ratio should be below 36%. Calculate by dividing total monthly debt payments by gross monthly income.",
                "metadata": {"topic": "debt_to_income", "category": "debt"}
            },
            {
                "content": "Dollar-cost averaging is investing a fixed amount regularly regardless of market conditions to reduce impact of volatility.",
                "metadata": {"topic": "dollar_cost_averaging", "category": "investing"}
            }
        ]
        
        try:
            self.collection.add(
                documents=[item["content"] for item in financial_knowledge],
                metadatas=[item["metadata"] for item in financial_knowledge],
                ids=[f"doc_{i}" for i in range(len(financial_knowledge))]
            )
        except Exception as e:
            print(f"Failed to populate knowledge base: {e}")
    
    def analyze_transactions(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Analyze transaction data and return insights"""
        if df.empty:
            return {"error": "No transaction data provided"}
        
        # Basic analysis
        total_income = df[df['type'] == 'credit']['amount'].sum()
        total_expenses = df[df['type'] == 'debit']['amount'].sum()
        net_income = total_income - total_expenses
        
        # Category analysis
        category_spending = df[df['type'] == 'debit'].groupby('category')['amount'].sum().sort_values(ascending=False)
        
        # Monthly trends
        df['month'] = df['date'].dt.to_period('M')
        monthly_spending = df[df['type'] == 'debit'].groupby('month')['amount'].sum()
        
        # Top merchants
        top_merchants = df[df['type'] == 'debit'].groupby('merchant')['amount'].sum().sort_values(ascending=False).head(10)
        
        analysis = {
            "total_income": round(total_income, 2),
            "total_expenses": round(total_expenses, 2),
            "net_income": round(net_income, 2),
            "savings_rate": round((net_income / total_income * 100), 2) if total_income > 0 else 0,
            "category_spending": category_spending.to_dict(),
            "monthly_spending": monthly_spending.to_dict(),
            "top_merchants": top_merchants.to_dict(),
            "transaction_count": len(df),
            "date_range": {
                "start": df['date'].min().strftime('%Y-%m-%d'),
                "end": df['date'].max().strftime('%Y-%m-%d')
            }
        }
        
        return analysis
    
    def calculate_financial_health_score(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall financial health score"""
        score = 0
        factors = {}
        
        # Savings rate (0-30 points)
        savings_rate = analysis.get('savings_rate', 0)
        if savings_rate >= 20:
            savings_score = 30
        elif savings_rate >= 15:
            savings_score = 25
        elif savings_rate >= 10:
            savings_score = 20
        elif savings_rate >= 5:
            savings_score = 15
        else:
            savings_score = max(0, savings_rate * 2)
        
        score += savings_score
        factors['savings_rate'] = {
            'value': savings_rate,
            'score': savings_score,
            'max_score': 30
        }
        
        # Spending consistency (0-25 points)
        monthly_spending = list(analysis.get('monthly_spending', {}).values())
        if len(monthly_spending) > 1:
            cv = np.std(monthly_spending) / np.mean(monthly_spending) if np.mean(monthly_spending) > 0 else 1
            consistency_score = max(0, 25 - (cv * 20))
        else:
            consistency_score = 15
        
        score += consistency_score
        factors['spending_consistency'] = {
            'value': 1 - cv if len(monthly_spending) > 1 else 0.8,
            'score': consistency_score,
            'max_score': 25
        }
        
        # Category diversity (0-20 points)
        category_count = len(analysis.get('category_spending', {}))
        diversity_score = min(20, category_count * 2)
        score += diversity_score
        factors['category_diversity'] = {
            'value': category_count,
            'score': diversity_score,
            'max_score': 20
        }
        
        # Income stability (0-25 points)
        # Simplified: assume stable income for demo
        income_score = 25
        score += income_score
        factors['income_stability'] = {
            'value': 1.0,
            'score': income_score,
            'max_score': 25
        }
        
        return {
            'total_score': min(100, max(0, score)),
            'grade': self._get_grade(score),
            'factors': factors,
            'recommendations': self._get_health_recommendations(score, factors)
        }
    
    def _get_grade(self, score: float) -> str:
        """Convert score to letter grade"""
        if score >= 90:
            return "A+"
        elif score >= 80:
            return "A"
        elif score >= 70:
            return "B+"
        elif score >= 60:
            return "B"
        elif score >= 50:
            return "C"
        else:
            return "D"
    
    def _get_health_recommendations(self, score: float, factors: Dict) -> List[str]:
        """Generate recommendations based on health score"""
        recommendations = []
        
        if factors['savings_rate']['score'] < 20:
            recommendations.append("Increase your savings rate to at least 15-20% of income")
        
        if factors['spending_consistency']['score'] < 15:
            recommendations.append("Try to maintain more consistent spending patterns")
        
        if factors['category_diversity']['value'] < 5:
            recommendations.append("Diversify your spending across more categories")
        
        if score < 60:
            recommendations.append("Focus on building an emergency fund")
            recommendations.append("Consider creating a detailed monthly budget")
        
        return recommendations
    
    def chat_with_ai(self, message: str, context: Dict[str, Any] = None) -> str:
        """Chat interface with AI using RAG for financial knowledge"""
        # First, try to retrieve relevant knowledge
        relevant_knowledge = []
        if self.vector_db:
            try:
                results = self.collection.query(
                    query_texts=[message],
                    n_results=3
                )
                if results['documents']:
                    relevant_knowledge = results['documents'][0]
            except Exception as e:
                print(f"RAG query failed: {e}")
        
        # Prepare context
        context_str = ""
        if context:
            context_str = f"""
            User's Financial Context:
            - Total Income: ${context.get('total_income', 0):,.2f}
            - Total Expenses: ${context.get('total_expenses', 0):,.2f}
            - Net Income: ${context.get('net_income', 0):,.2f}
            - Savings Rate: {context.get('savings_rate', 0):.1f}%
            - Top Spending Categories: {list(context.get('category_spending', {}).keys())[:3]}
            """
        
        knowledge_str = ""
        if relevant_knowledge:
            knowledge_str = f"\nRelevant Financial Knowledge:\n" + "\n".join(relevant_knowledge)
        
        # Create prompt
        prompt = f"""You are FinGenius, an AI-powered personal finance advisor. You help users understand their finances and make better money decisions.

{context_str}{knowledge_str}

User Question: {message}

Please provide a helpful, actionable response. Be specific and practical. If the user asks about financial concepts, explain them clearly. If they ask for advice, give evidence-based recommendations.

Response:"""
        
        try:
            if "gpt" in self.model_name.lower():
                response = self.client.chat.completions.create(
                    model=self.model_name,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.7,
                    max_tokens=500
                )
                return response.choices[0].message.content
            elif "gemini" in self.model_name.lower():
                response = self.client.generate_content(prompt)
                return response.text
            else:
                return "AI model not properly configured. Please check your API keys."
        except Exception as e:
            return f"I apologize, but I'm having trouble processing your request right now. Error: {str(e)}"
    
    def generate_budget_recommendations(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Generate personalized budget recommendations"""
        total_income = analysis.get('total_income', 0)
        category_spending = analysis.get('category_spending', {})
        
        # 50/30/20 rule application
        needs_budget = total_income * 0.5
        wants_budget = total_income * 0.3
        savings_budget = total_income * 0.2
        
        # Categorize current spending
        needs_categories = ['Rent/Mortgage', 'Bills & Utilities', 'Groceries', 'Healthcare', 'Insurance']
        wants_categories = ['Entertainment', 'Shopping', 'Food & Dining', 'Travel']
        
        current_needs = sum(category_spending.get(cat, 0) for cat in needs_categories)
        current_wants = sum(category_spending.get(cat, 0) for cat in wants_categories)
        
        recommendations = {
            'budget_rule': '50/30/20',
            'recommended_budgets': {
                'needs': round(needs_budget, 2),
                'wants': round(wants_budget, 2),
                'savings': round(savings_budget, 2)
            },
            'current_spending': {
                'needs': round(current_needs, 2),
                'wants': round(current_wants, 2),
                'savings': round(analysis.get('net_income', 0), 2)
            },
            'adjustments_needed': {
                'needs': round(needs_budget - current_needs, 2),
                'wants': round(wants_budget - current_wants, 2),
                'savings': round(savings_budget - analysis.get('net_income', 0), 2)
            },
            'category_recommendations': {}
        }
        
        # Category-specific recommendations
        for category, amount in category_spending.items():
            if category in needs_categories:
                target = needs_budget * 0.2  # Distribute needs budget across categories
            elif category in wants_categories:
                target = wants_budget * 0.25  # Distribute wants budget across categories
            else:
                continue
                
            recommendations['category_recommendations'][category] = {
                'current': round(amount, 2),
                'recommended': round(target, 2),
                'adjustment': round(target - amount, 2)
            }
        
        return recommendations
