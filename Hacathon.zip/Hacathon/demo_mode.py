"""
Demo Mode for FinGenius - Works without API keys
Perfect for hackathon presentations when API setup isn't available
"""
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import random

# Mock AI responses for demo
DEMO_AI_RESPONSES = {
    "save_money": "Based on your spending analysis, I recommend reducing dining out expenses by 30% and switching to a high-yield savings account. This could save you approximately $200-300 per month.",
    
    "spending_patterns": "Your spending shows a pattern of higher expenses on weekends and during travel periods. You spend 24% on rent, 20% on travel, and 18% on dining out. Consider setting weekly spending limits.",
    
    "budget_plan": "Here's a recommended budget based on your income: 50% for needs (rent, utilities, groceries), 30% for wants (entertainment, dining), and 20% for savings and debt repayment.",
    
    "investment_advice": "With your current savings rate of 15%, consider opening a Roth IRA and investing in low-cost index funds. Start with $100-200 per month and increase gradually.",
    
    "debt_management": "Focus on paying off high-interest debt first. Consider the debt snowball method - pay minimums on all debts, then put extra money toward the smallest debt first.",
    
    "financial_goals": "Set SMART financial goals: Specific, Measurable, Achievable, Relevant, and Time-bound. For example: 'Save $5,000 emergency fund in 12 months' by setting aside $417 per month."
}

def demo_mode():
    """Run FinGenius in demo mode without API keys"""
    
    st.set_page_config(
        page_title="FinGenius Demo",
        page_icon="💰",
        layout="wide"
    )
    
    st.title("💰 FinGenius - AI-Powered Personal Finance Advisor")
    st.subheader("🎮 Demo Mode - No API Keys Required")
    
    st.info("🚀 **Demo Mode Active** - This version works without API keys and shows all FinGenius features with sample data and mock AI responses.")
    
    # Load sample data
    df = pd.read_csv('sample_transactions.csv')
    
    # Calculate demo metrics
    total_income = df[df['type'] == 'credit']['amount'].sum()
    total_expenses = df[df['type'] == 'debit']['amount'].sum()
    net_income = total_income - total_expenses
    savings_rate = (net_income / total_income * 100) if total_income > 0 else 0
    
    # Demo metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("💰 Total Income", f"${total_income:,.0f}")
    
    with col2:
        st.metric("💸 Total Expenses", f"${total_expenses:,.0f}")
    
    with col3:
        st.metric("📈 Net Income", f"${net_income:,.0f}")
    
    with col4:
        st.metric("🎯 Savings Rate", f"{savings_rate:.1f}%")
    
    # Demo charts
    st.subheader("📊 Spending Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Category spending
        category_spending = df[df['type'] == 'debit'].groupby('category')['amount'].sum().sort_values(ascending=False)
        fig1 = px.pie(values=category_spending.values, names=category_spending.index, 
                     title="Spending by Category")
        st.plotly_chart(fig1, use_container_width=True)
    
    with col2:
        # Monthly trend
        df['month'] = pd.to_datetime(df['date']).dt.to_period('M')
        monthly_spending = df[df['type'] == 'debit'].groupby('month')['amount'].sum()
        fig2 = px.line(x=[str(m) for m in monthly_spending.index], 
                      y=monthly_spending.values,
                      title="Monthly Spending Trend")
        st.plotly_chart(fig2, use_container_width=True)
    
    # Demo AI Chat
    st.subheader("🤖 AI Financial Advisor (Demo Mode)")
    
    # Quick demo buttons
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("💡 How can I save more?"):
            st.info(f"**FinGenius (Demo):** {DEMO_AI_RESPONSES['save_money']}")
    
    with col2:
        if st.button("📊 Explain my spending"):
            st.info(f"**FinGenius (Demo):** {DEMO_AI_RESPONSES['spending_patterns']}")
    
    with col3:
        if st.button("🎯 Set a budget"):
            st.info(f"**FinGenius (Demo):** {DEMO_AI_RESPONSES['budget_plan']}")
    
    # Demo chat input
    if user_input := st.chat_input("Ask me about your finances..."):
        # Simple keyword matching for demo
        response = "I'm in demo mode, but I can help analyze your spending patterns and provide financial advice. In the full version, I'd use advanced AI to give personalized recommendations based on your data."
        
        if "save" in user_input.lower():
            response = DEMO_AI_RESPONSES['save_money']
        elif "spending" in user_input.lower() or "pattern" in user_input.lower():
            response = DEMO_AI_RESPONSES['spending_patterns']
        elif "budget" in user_input.lower():
            response = DEMO_AI_RESPONSES['budget_plan']
        elif "invest" in user_input.lower():
            response = DEMO_AI_RESPONSES['investment_advice']
        elif "debt" in user_input.lower():
            response = DEMO_AI_RESPONSES['debt_management']
        elif "goal" in user_input.lower():
            response = DEMO_AI_RESPONSES['financial_goals']
        
        st.info(f"**FinGenius (Demo):** {response}")
    
    # Demo features showcase
    st.subheader("✨ FinGenius Features (Full Version)")
    
    features = [
        "🤖 **Real AI Analysis** - GPT-4 powered financial insights",
        "📊 **Advanced Analytics** - Deep spending pattern analysis", 
        "💬 **Conversational AI** - Natural language financial advice",
        "🎯 **Personalized Recommendations** - Tailored to your spending",
        "📈 **Predictive Insights** - Future financial forecasting",
        "🔒 **Secure Data Processing** - Your data stays private"
    ]
    
    for feature in features:
        st.markdown(feature)
    
    # Demo conclusion
    st.success("🎉 **Demo Complete!** This shows FinGenius capabilities. The full version includes real AI analysis, advanced RAG technology, and personalized recommendations based on your actual financial data.")

if __name__ == "__main__":
    demo_mode()
