"""
Visualization components for FinGenius dashboard
"""
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

class FinGeniusVisualizations:
    def __init__(self):
        self.color_palette = [
            '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
            '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
        ]
    
    def spending_by_category_chart(self, category_data: dict, title: str = "Spending by Category") -> go.Figure:
        """Create a pie chart for spending by category"""
        if not category_data:
            return self._empty_chart("No spending data available")
        
        categories = list(category_data.keys())
        amounts = list(category_data.values())
        
        fig = go.Figure(data=[go.Pie(
            labels=categories,
            values=amounts,
            hole=0.4,
            marker_colors=self.color_palette[:len(categories)]
        )])
        
        fig.update_layout(
            title=title,
            showlegend=True,
            height=400,
            font=dict(size=12)
        )
        
        return fig
    
    def monthly_spending_trend(self, monthly_data: dict, title: str = "Monthly Spending Trend") -> go.Figure:
        """Create a line chart for monthly spending trends"""
        if not monthly_data:
            return self._empty_chart("No monthly data available")
        
        # Convert period keys to datetime
        dates = []
        amounts = []
        
        for period_str, amount in monthly_data.items():
            # Handle period string format (e.g., "2024-01")
            if isinstance(period_str, str):
                try:
                    date = datetime.strptime(period_str, "%Y-%m")
                except:
                    date = datetime.strptime(period_str, "%Y-%m-%d")
            else:
                date = period_str.to_timestamp()
            
            dates.append(date)
            amounts.append(amount)
        
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=dates,
            y=amounts,
            mode='lines+markers',
            name='Spending',
            line=dict(color='#2E86AB', width=3),
            marker=dict(size=8)
        ))
        
        fig.update_layout(
            title=title,
            xaxis_title="Month",
            yaxis_title="Amount ($)",
            height=400,
            showlegend=False,
            hovermode='x unified'
        )
        
        return fig
    
    def financial_health_gauge(self, score: float, grade: str, title: str = "Financial Health Score") -> go.Figure:
        """Create a gauge chart for financial health score"""
        fig = go.Figure(go.Indicator(
            mode = "gauge+number+delta",
            value = score,
            domain = {'x': [0, 1], 'y': [0, 1]},
            title = {'text': title},
            delta = {'reference': 70},
            gauge = {
                'axis': {'range': [None, 100]},
                'bar': {'color': "darkblue"},
                'steps': [
                    {'range': [0, 50], 'color': "lightgray"},
                    {'range': [50, 70], 'color': "yellow"},
                    {'range': [70, 100], 'color': "green"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 90
                }
            }
        ))
        
        fig.update_layout(
            height=300,
            font={'color': "darkblue", 'family': "Arial"}
        )
        
        return fig
    
    def top_merchants_chart(self, merchant_data: dict, title: str = "Top Spending Locations") -> go.Figure:
        """Create a horizontal bar chart for top merchants"""
        if not merchant_data:
            return self._empty_chart("No merchant data available")
        
        # Get top 10 merchants
        sorted_merchants = sorted(merchant_data.items(), key=lambda x: x[1], reverse=True)[:10]
        merchants = [item[0] for item in sorted_merchants]
        amounts = [item[1] for item in sorted_merchants]
        
        fig = go.Figure(data=[
            go.Bar(
                y=merchants,
                x=amounts,
                orientation='h',
                marker_color='#FF6B6B'
            )
        ])
        
        fig.update_layout(
            title=title,
            xaxis_title="Amount Spent ($)",
            yaxis_title="Merchant",
            height=400,
            showlegend=False
        )
        
        return fig
    
    def budget_vs_actual_chart(self, budget_data: dict, title: str = "Budget vs Actual Spending") -> go.Figure:
        """Create a comparison chart for budget vs actual spending"""
        if not budget_data:
            return self._empty_chart("No budget data available")
        
        categories = list(budget_data.keys())
        recommended = [data.get('recommended', 0) for data in budget_data.values()]
        actual = [data.get('current', 0) for data in budget_data.values()]
        
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            name='Recommended',
            x=categories,
            y=recommended,
            marker_color='lightblue'
        ))
        
        fig.add_trace(go.Bar(
            name='Actual',
            x=categories,
            y=actual,
            marker_color='orange'
        ))
        
        fig.update_layout(
            title=title,
            xaxis_title="Category",
            yaxis_title="Amount ($)",
            barmode='group',
            height=400,
            xaxis_tickangle=-45
        )
        
        return fig
    
    def income_vs_expenses_chart(self, analysis: dict, title: str = "Income vs Expenses") -> go.Figure:
        """Create a comparison of income vs expenses"""
        total_income = analysis.get('total_income', 0)
        total_expenses = analysis.get('total_expenses', 0)
        net_income = analysis.get('net_income', 0)
        
        categories = ['Total Income', 'Total Expenses', 'Net Income']
        amounts = [total_income, total_expenses, net_income]
        colors = ['green', 'red', 'blue']
        
        fig = go.Figure(data=[
            go.Bar(
                x=categories,
                y=amounts,
                marker_color=colors,
                text=[f'${amount:,.0f}' for amount in amounts],
                textposition='auto'
            )
        ])
        
        fig.update_layout(
            title=title,
            yaxis_title="Amount ($)",
            height=400,
            showlegend=False
        )
        
        return fig
    
    def spending_pattern_heatmap(self, df: pd.DataFrame, title: str = "Spending Pattern Heatmap") -> go.Figure:
        """Create a heatmap showing spending patterns by day of week and hour"""
        if df.empty:
            return self._empty_chart("No transaction data available")
        
        # Prepare data
        df_copy = df.copy()
        df_copy['day_of_week'] = df_copy['date'].dt.day_name()
        df_copy['hour'] = df_copy['date'].dt.hour
        
        # Create pivot table
        heatmap_data = df_copy.groupby(['day_of_week', 'hour'])['amount'].sum().unstack(fill_value=0)
        
        # Reorder days
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        heatmap_data = heatmap_data.reindex(day_order)
        
        fig = go.Figure(data=go.Heatmap(
            z=heatmap_data.values,
            x=heatmap_data.columns,
            y=heatmap_data.index,
            colorscale='Blues',
            hoverongaps=False
        ))
        
        fig.update_layout(
            title=title,
            xaxis_title="Hour of Day",
            yaxis_title="Day of Week",
            height=400
        )
        
        return fig
    
    def _empty_chart(self, message: str) -> go.Figure:
        """Create an empty chart with a message"""
        fig = go.Figure()
        fig.add_annotation(
            text=message,
            xref="paper", yref="paper",
            x=0.5, y=0.5, xanchor='center', yanchor='middle',
            showarrow=False, font_size=16
        )
        fig.update_layout(
            xaxis={'visible': False},
            yaxis={'visible': False},
            height=300
        )
        return fig
    
    def create_dashboard_summary(self, analysis: dict, health_score: dict) -> str:
        """Create a text summary for the dashboard"""
        summary = f"""
        ## 📊 Financial Summary
        
        **💰 Total Income:** ${analysis.get('total_income', 0):,.2f}  
        **💸 Total Expenses:** ${analysis.get('total_expenses', 0):,.2f}  
        **📈 Net Income:** ${analysis.get('net_income', 0):,.2f}  
        **💎 Savings Rate:** {analysis.get('savings_rate', 0):.1f}%  
        **🎯 Financial Health Score:** {health_score.get('total_score', 0)}/100 ({health_score.get('grade', 'N/A')})  
        
        **📅 Analysis Period:** {analysis.get('date_range', {}).get('start', 'N/A')} to {analysis.get('date_range', {}).get('end', 'N/A')}  
        **📋 Total Transactions:** {analysis.get('transaction_count', 0):,}  
        
        """
        
        # Add top spending category
        category_spending = analysis.get('category_spending', {})
        if category_spending:
            top_category = max(category_spending.items(), key=lambda x: x[1])
            summary += f"**🏆 Top Spending Category:** {top_category[0]} (${top_category[1]:,.2f})\n\n"
        
        return summary
