"""
Configuration settings for FinGenius
"""
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# API Keys
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', 'your_openai_api_key_here')
GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY', 'your_google_gemini_api_key_here')

# Model Settings
DEFAULT_AI_MODEL = "gpt-3.5-turbo"  # Can switch to "gemini-pro"
EMBEDDING_MODEL = "text-embedding-ada-002"

# App Settings
APP_TITLE = "FinGenius - AI-Powered Personal Finance Advisor"
APP_ICON = "💰"

# Financial Categories
SPENDING_CATEGORIES = [
    "Food & Dining", "Transportation", "Shopping", "Entertainment", 
    "Bills & Utilities", "Healthcare", "Travel", "Education", 
    "Groceries", "Gas", "Insurance", "Rent/Mortgage", "Other"
]

# Financial Health Score Weights
HEALTH_SCORE_WEIGHTS = {
    "savings_rate": 0.3,
    "debt_to_income": 0.25,
    "spending_consistency": 0.2,
    "emergency_fund": 0.15,
    "budget_adherence": 0.1
}
