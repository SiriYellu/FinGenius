"""
Generate realistic sample transaction data for demo purposes
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from faker import Faker
import random

fake = Faker()

class TransactionDataGenerator:
    def __init__(self):
        self.categories = [
            "Food & Dining", "Transportation", "Shopping", "Entertainment", 
            "Bills & Utilities", "Healthcare", "Travel", "Education", 
            "Groceries", "Gas", "Insurance", "Rent/Mortgage", "Other"
        ]
        
        self.merchants = {
            "Food & Dining": ["McDonald's", "Starbucks", "Chipotle", "Pizza Hut", "Local Restaurant", "Food Truck"],
            "Transportation": ["Uber", "Lyft", "Metro", "Parking", "Toll Road", "Taxi"],
            "Shopping": ["Amazon", "Target", "Walmart", "Best Buy", "Nike", "Zara"],
            "Entertainment": ["Netflix", "Spotify", "Movie Theater", "Concert", "Arcade", "Bowling"],
            "Bills & Utilities": ["Electric Company", "Water Bill", "Internet Provider", "Phone Bill", "Cable"],
            "Healthcare": ["CVS Pharmacy", "Doctor Visit", "Dentist", "Urgent Care", "Prescription"],
            "Travel": ["Airline", "Hotel", "Airbnb", "Rental Car", "Travel Insurance"],
            "Education": ["Bookstore", "Online Course", "University", "Software License", "Training"],
            "Groceries": ["Kroger", "Whole Foods", "Safeway", "Costco", "Trader Joe's"],
            "Gas": ["Shell", "Exxon", "BP", "Chevron", "Local Gas Station"],
            "Insurance": ["Auto Insurance", "Health Insurance", "Home Insurance", "Life Insurance"],
            "Rent/Mortgage": ["Landlord", "Mortgage Company", "Property Management", "HOA"],
            "Other": ["ATM Withdrawal", "Bank Fee", "Transfer", "Cash", "Miscellaneous"]
        }
        
    def generate_transactions(self, months=6, transactions_per_month=50):
        """Generate realistic transaction data"""
        transactions = []
        start_date = datetime.now() - timedelta(days=months*30)
        
        for month in range(months):
            month_start = start_date + timedelta(days=month*30)
            
            for _ in range(transactions_per_month):
                # Generate date within the month
                transaction_date = month_start + timedelta(
                    days=random.randint(0, 29),
                    hours=random.randint(8, 22),
                    minutes=random.randint(0, 59)
                )
                
                # Select category with weighted probability
                category = np.random.choice(
                    self.categories,
                    p=[0.15, 0.12, 0.10, 0.08, 0.12, 0.05, 0.03, 0.02, 
                       0.15, 0.08, 0.05, 0.02, 0.03]
                )
                
                # Generate merchant
                merchant = random.choice(self.merchants[category])
                
                # Generate amount based on category
                amount = self._generate_amount(category)
                
                # Generate description
                description = self._generate_description(category, merchant, amount)
                
                transaction = {
                    'date': transaction_date,
                    'description': description,
                    'category': category,
                    'amount': round(amount, 2),
                    'merchant': merchant,
                    'type': 'debit' if random.random() > 0.15 else 'credit'
                }
                
                transactions.append(transaction)
        
        # Add some income transactions
        for _ in range(months):
            income_date = start_date + timedelta(days=random.randint(0, months*30))
            transactions.append({
                'date': income_date,
                'description': 'Salary Deposit',
                'category': 'Income',
                'amount': round(random.uniform(3000, 5000), 2),
                'merchant': 'Employer',
                'type': 'credit'
            })
        
        # Sort by date
        transactions.sort(key=lambda x: x['date'])
        
        return pd.DataFrame(transactions)
    
    def _generate_amount(self, category):
        """Generate realistic amounts based on category"""
        base_amounts = {
            "Food & Dining": (8, 45),
            "Transportation": (3, 25),
            "Shopping": (15, 200),
            "Entertainment": (10, 100),
            "Bills & Utilities": (50, 300),
            "Healthcare": (20, 500),
            "Travel": (100, 2000),
            "Education": (30, 500),
            "Groceries": (40, 150),
            "Gas": (25, 80),
            "Insurance": (100, 400),
            "Rent/Mortgage": (800, 2500),
            "Other": (5, 50)
        }
        
        min_amt, max_amt = base_amounts.get(category, (10, 100))
        return random.uniform(min_amt, max_amt)
    
    def _generate_description(self, category, merchant, amount):
        """Generate realistic transaction descriptions"""
        descriptions = {
            "Food & Dining": f"Purchase at {merchant}",
            "Transportation": f"{merchant} ride",
            "Shopping": f"Online purchase - {merchant}",
            "Entertainment": f"Subscription - {merchant}",
            "Bills & Utilities": f"Bill payment - {merchant}",
            "Healthcare": f"Medical expense - {merchant}",
            "Travel": f"Travel expense - {merchant}",
            "Education": f"Education - {merchant}",
            "Groceries": f"Grocery shopping - {merchant}",
            "Gas": f"Gas purchase - {merchant}",
            "Insurance": f"Insurance payment - {merchant}",
            "Rent/Mortgage": f"Housing payment - {merchant}",
            "Other": f"Transaction - {merchant}"
        }
        
        return descriptions.get(category, f"Purchase at {merchant}")

def create_sample_data():
    """Create and save sample data"""
    generator = TransactionDataGenerator()
    df = generator.generate_transactions(months=6, transactions_per_month=60)
    
    # Save to CSV
    df.to_csv('sample_transactions.csv', index=False)
    print(f"Generated {len(df)} sample transactions")
    
    return df

if __name__ == "__main__":
    create_sample_data()
