# FinGenius Setup Guide
## API Keys & Credentials Setup

### 🔑 **Required API Keys**

FinGenius uses AI models for financial analysis and recommendations. You need to set up API keys for the AI features to work properly.

---

## 📋 **Step-by-Step Setup**

### **Option 1: OpenAI API Key (Recommended for Demo)**

1. **Get OpenAI API Key:**
   - Go to [OpenAI Platform](https://platform.openai.com/)
   - Sign up or log in
   - Go to API Keys section
   - Create a new API key
   - Copy the key (starts with `sk-...`)

2. **Set Environment Variable:**
   ```bash
   # On Mac/Linux
   export OPENAI_API_KEY="your_api_key_here"
   
   # On Windows
   set OPENAI_API_KEY=your_api_key_here
   ```

### **Option 2: Google Gemini API Key (Alternative)**

1. **Get Google API Key:**
   - Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
   - Sign in with Google account
   - Create a new API key
   - Copy the key

2. **Set Environment Variable:**
   ```bash
   # On Mac/Linux
   export GOOGLE_API_KEY="your_api_key_here"
   
   # On Windows
   set GOOGLE_API_KEY=your_api_key_here
   ```

### **Option 3: Create .env File (Easiest)**

1. **Create .env file in project root:**
   ```bash
   touch .env
   ```

2. **Add your API keys:**
   ```env
   OPENAI_API_KEY=your_openai_api_key_here
   GOOGLE_API_KEY=your_google_api_key_here
   ```

---

## 🚀 **Quick Setup for Demo**

### **For Hackathon Demo (Recommended):**

1. **Use OpenAI API Key:**
   - Sign up for OpenAI (free credits available)
   - Get API key from platform.openai.com
   - Create `.env` file with your key

2. **Run the app:**
   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```

---

## 💡 **Demo Without API Keys**

If you want to demo without setting up API keys, you can:

1. **Use the demo mode** - The app will show sample data and UI
2. **Mock AI responses** - Show the interface without real AI
3. **Focus on upload feature** - Highlight the data processing capabilities

---

## 🔧 **Troubleshooting**

### **Common Issues:**

1. **"API Key not found" error:**
   - Check if .env file exists in project root
   - Verify API key is correctly formatted
   - Restart the app after adding keys

2. **"Rate limit exceeded" error:**
   - OpenAI has usage limits on free accounts
   - Consider using Google Gemini as alternative
   - Or upgrade to paid OpenAI plan

3. **"Model not available" error:**
   - Check if API key has access to the model
   - Try switching between OpenAI and Gemini

---

## 💰 **Cost Considerations**

### **OpenAI Pricing:**
- **GPT-3.5-turbo:** ~$0.002 per 1K tokens
- **Demo usage:** Typically $1-5 for full demo
- **Free credits:** New accounts get $5 free

### **Google Gemini:**
- **Free tier:** 60 requests per minute
- **Paid tier:** $0.0005 per 1K tokens
- **Good for:** High-volume demos

---

## 🎯 **For Hackathon Presentation**

### **Recommended Setup:**
1. **Get OpenAI API key** (easiest setup)
2. **Create .env file** with your key
3. **Test the app** before presentation
4. **Have backup plan** (demo mode) if API fails

### **Presentation Tips:**
- **Test upload feature** - works without API keys
- **Show AI responses** - demonstrates real AI integration
- **Explain the technology** - RAG, embeddings, function calling
- **Highlight real-world applicability** - not just a demo

---

## ✅ **Quick Start Checklist**

- [ ] Get OpenAI API key from platform.openai.com
- [ ] Create `.env` file in project root
- [ ] Add `OPENAI_API_KEY=your_key_here` to .env file
- [ ] Install dependencies: `pip install -r requirements.txt`
- [ ] Run app: `streamlit run app.py`
- [ ] Test upload feature
- [ ] Test AI chat functionality

---

## 🏆 **Ready for Demo!**

Once you have the API key set up:

1. **Upload data** - Shows real data processing
2. **AI analysis** - Demonstrates intelligent insights
3. **Chat interface** - Shows conversational AI
4. **Visualizations** - Interactive charts and graphs

**Your FinGenius app will be fully functional and ready to impress the judges!** 🚀💰
