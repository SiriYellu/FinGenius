"""
FinGenius - AI-Powered Personal Finance Advisor
Main Streamlit Application
"""
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import os

# Import our custom modules
from ai_engine import AIEngine
from visualizations import FinGeniusVisualizations
from data_generator import TransactionDataGenerator
from config import APP_TITLE, APP_ICON

# Page configuration
st.set_page_config(
    page_title="FinGenius",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Clean and Professional CSS for Presentation
st.markdown("""
<style>
    /* Reset and Base Styles */
    .main .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
        max-width: 1200px;
    }
    
    /* Main Header */
    .main-header {
        font-size: 3rem;
        font-weight: 700;
        text-align: center;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 1.5rem;
    }
    
    /* Clean Section Headers */
    .section-header {
        font-size: 1.8rem;
        font-weight: 600;
        color: #2c3e50;
        margin: 1.5rem 0 1rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 2px solid #667eea;
    }
    
    /* Clean Info Boxes */
    .info-box {
        background: #f8f9fa;
        padding: 1.2rem;
        border-radius: 8px;
        border-left: 4px solid #667eea;
        margin: 1rem 0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    .success-box {
        background: #f0f9ff;
        border-left: 4px solid #10b981;
    }
    
    .warning-box {
        background: #fffbeb;
        border-left: 4px solid #f59e0b;
    }
    
    .error-box {
        background: #fef2f2;
        border-left: 4px solid #ef4444;
    }
    
    /* Clean Metric Cards */
    .metric-card {
        background: white;
        padding: 1.5rem;
        border-radius: 8px;
        border: 1px solid #e5e7eb;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        margin-bottom: 1rem;
        text-align: center;
    }
    
    /* Health Score */
    .health-score {
        font-size: 2rem;
        font-weight: bold;
        text-align: center;
        padding: 1.5rem;
        border-radius: 8px;
        margin: 1rem 0;
    }
    
    .score-excellent { 
        background: #dcfce7;
        color: #166534;
        border: 2px solid #22c55e;
    }
    
    .score-good { 
        background: #dbeafe;
        color: #1e40af;
        border: 2px solid #3b82f6;
    }
    
    .score-fair { 
        background: #fef3c7;
        color: #92400e;
        border: 2px solid #f59e0b;
    }
    
    .score-poor { 
        background: #fee2e2;
        color: #991b1b;
        border: 2px solid #ef4444;
    }
    
    /* Clean Chart Containers */
    .chart-container {
        background: white;
        border-radius: 8px;
        padding: 1rem;
        border: 1px solid #e5e7eb;
        margin: 1rem 0;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    
    /* Clean Upload Area */
    .upload-area {
        border: 2px dashed #d1d5db;
        border-radius: 8px;
        padding: 2rem;
        text-align: center;
        background: #f9fafb;
        transition: all 0.2s ease;
    }
    
    .upload-area:hover {
        border-color: #667eea;
        background: #f3f4f6;
    }
    
    /* Clean Buttons */
    .stButton > button {
        background: #667eea;
        color: white;
        border: none;
        border-radius: 6px;
        padding: 0.5rem 1.5rem;
        font-weight: 500;
        transition: all 0.2s ease;
    }
    
    .stButton > button:hover {
        background: #5a67d8;
        transform: translateY(-1px);
    }
    
    /* Clean Chat Messages */
    .user-message {
        background: #667eea;
        color: white;
        padding: 0.8rem 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
    }
    
    .ai-message {
        background: #f3f4f6;
        color: #374151;
        padding: 0.8rem 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
        border-left: 3px solid #667eea;
    }
    
    /* Clean Data Tables */
    .data-table {
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid #e5e7eb;
    }
    
    /* Sidebar Cleanup */
    .sidebar .sidebar-content {
        background: #f9fafb;
    }
    
    /* Remove Streamlit Branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    
    /* Clean Spacing */
    .element-container {
        margin-bottom: 1rem;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .main-header {
            font-size: 2.5rem;
        }
        
        .metric-card {
            padding: 1rem;
        }
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_sample_data():
    """Load or generate sample transaction data"""
    if os.path.exists('sample_transactions.csv'):
        return pd.read_csv('sample_transactions.csv')
    else:
        # Generate new sample data
        generator = TransactionDataGenerator()
        df = generator.generate_transactions(months=6, transactions_per_month=60)
        df.to_csv('sample_transactions.csv', index=False)
        return df

@st.cache_resource
def initialize_ai_engine():
    """Initialize the AI engine"""
    return AIEngine()

@st.cache_resource
def initialize_visualizations():
    """Initialize visualization components"""
    return FinGeniusVisualizations()

def main():
    """Main application function"""
    
    # Enhanced Header with subtitle
    st.markdown(f'<h1 class="main-header">{APP_ICON} {APP_TITLE}</h1>', unsafe_allow_html=True)
    st.markdown('''
    <div style="text-align: center; margin-bottom: 2rem;">
        <h3 style="color: #7f8c8d; font-weight: 400; margin: 0;">AI-Powered Personal Finance Advisor</h3>
        <p style="color: #95a5a6; font-size: 1.1rem; margin: 0.5rem 0;">Transform your financial data into actionable insights through intelligent conversation</p>
    </div>
    ''', unsafe_allow_html=True)
    
    # Initialize components
    ai_engine = initialize_ai_engine()
    viz = initialize_visualizations()
    
    # Sidebar
    st.sidebar.title("🎛️ Navigation")
    page = st.sidebar.selectbox(
        "Choose a page:",
        ["📁 Upload Data", "📊 Dashboard", "🤖 AI Advisor", "📈 Analytics", "💡 Insights", "⚙️ Settings"]
    )
    
    # Load data
    with st.spinner("Loading your financial data..."):
        # Check if user uploaded their own data
        if st.session_state.get('use_uploaded_data', False) and st.session_state.get('uploaded_data') is not None:
            df = st.session_state.uploaded_data.copy()
            st.success("📁 Using your uploaded data!")
        else:
            df = load_sample_data()
            df['date'] = pd.to_datetime(df['date'])
        
        # Perform analysis
        analysis = ai_engine.analyze_transactions(df)
        health_score = ai_engine.calculate_financial_health_score(analysis)
    
    # Main content based on selected page
    if page == "📁 Upload Data":
        show_upload_page(analysis, health_score, df, viz)
    elif page == "📊 Dashboard":
        show_dashboard(analysis, health_score, df, viz)
    elif page == "🤖 AI Advisor":
        show_ai_advisor(ai_engine, analysis)
    elif page == "📈 Analytics":
        show_analytics(df, analysis, viz)
    elif page == "💡 Insights":
        show_insights(ai_engine, analysis, health_score)
    elif page == "⚙️ Settings":
        show_settings()
    
    # Professional Footer
    st.markdown('---')
    st.markdown('''
    <div style="text-align: center; padding: 2rem 0; color: #7f8c8d;">
        <p style="margin: 0; font-size: 0.9rem;">
            <strong>FinGenius</strong> - AI-Powered Personal Finance Advisor | 
            Built with ❤️ for the Fall 2025 Kennesaw State University FinTech Hackathon
        </p>
        <p style="margin: 0.5rem 0 0 0; font-size: 0.8rem;">
            Powered by OpenAI GPT & Google Gemini | 
            <a href="#" style="color: #667eea; text-decoration: none;">Privacy Policy</a> | 
            <a href="#" style="color: #667eea; text-decoration: none;">Terms of Service</a>
        </p>
    </div>
    ''', unsafe_allow_html=True)

def show_upload_page(analysis, health_score, df, viz):
    """Display the main upload page - clean and organized for presentation"""
    
    # Clean header
    st.markdown('<h1 class="section-header">📁 Upload Your Financial Data</h1>', unsafe_allow_html=True)
    
    # Introduction
    st.info("🚀 **Get Started with FinGenius** - Upload your transaction data to get personalized AI-powered financial insights and recommendations.")
    
    # Main layout
    col1, col2 = st.columns([3, 2])
    
    with col1:
        st.markdown("### 📊 Upload Your Transaction Data")
        
        # Clean file uploader
        uploaded_file = st.file_uploader(
            "Choose your CSV file",
            type=['csv'],
            help="Upload a CSV file with columns: date, description, category, amount, merchant, type",
            key="main_upload"
        )
        
        if uploaded_file is not None:
            try:
                # Read the uploaded file
                df_uploaded = pd.read_csv(uploaded_file)
                
                # Validate columns
                required_columns = ['date', 'description', 'category', 'amount', 'merchant', 'type']
                if all(col in df_uploaded.columns for col in required_columns):
                    # Convert date column
                    df_uploaded['date'] = pd.to_datetime(df_uploaded['date'])
                    
                    # Success message
                    st.success(f"✅ **Upload Successful!** {len(df_uploaded)} transactions uploaded and validated.")
                    
                    # Store in session state
                    st.session_state.uploaded_data = df_uploaded
                    st.session_state.use_uploaded_data = True
                    
                    # Show preview
                    st.markdown("**📋 Data Preview:**")
                    st.dataframe(df_uploaded.head(5), use_container_width=True)
                    
                    # Analyze button
                    if st.button("🚀 Analyze My Data", key="analyze_uploaded"):
                        st.session_state.analyze_uploaded = True
                        st.rerun()
                        
                else:
                    st.error("❌ **Invalid File Format** - CSV must have columns: date, description, category, amount, merchant, type")
                    
                    # Show example format
                    st.markdown("**💡 Expected Format:**")
                    example_data = {
                        'date': ['2024-01-15', '2024-01-16', '2024-01-17'],
                        'description': ['Grocery Shopping', 'Gas Station', 'Salary Deposit'],
                        'category': ['Groceries', 'Gas', 'Income'],
                        'amount': [150.00, 45.00, 3000.00],
                        'merchant': ['Kroger', 'Shell', 'Employer'],
                        'type': ['debit', 'debit', 'credit']
                    }
                    example_df = pd.DataFrame(example_data)
                    st.dataframe(example_df, use_container_width=True)
                    
            except Exception as e:
                st.error(f"❌ **Error Reading File:** {str(e)}")
    
    with col2:
        st.markdown("### 🎯 Quick Actions")
        
        # Download sample data
        st.markdown("**📥 Get Sample Data**")
        if os.path.exists('sample_upload.csv'):
            with open('sample_upload.csv', 'r') as f:
                st.download_button(
                    label="Download Sample CSV",
                    data=f.read(),
                    file_name="sample_transactions.csv",
                    mime="text/csv"
                )
        
        st.markdown("---")
        
        # Try demo data
        st.markdown("**🎮 Try Demo Data**")
        if st.button("Use Demo Data", help="Switch to sample data"):
            st.session_state.use_uploaded_data = False
            st.success("Switched to demo data!")
        
        st.markdown("---")
        
        # Current data source
        st.markdown("**🔄 Current Data Source**")
        if st.session_state.get('use_uploaded_data', False) and st.session_state.get('uploaded_data') is not None:
            st.success(f"📁 Your Data ({len(st.session_state.uploaded_data)} transactions)")
        else:
            st.info("📊 Demo Data (366 transactions)")
    
    # Features showcase - clean and organized
    st.markdown("---")
    st.markdown("### ✨ What FinGenius Can Do")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("**🤖 AI Advisor**")
        st.markdown("Chat with AI about your finances")
    
    with col2:
        st.markdown("**📊 Analytics**")
        st.markdown("Deep insights into spending patterns")
    
    with col3:
        st.markdown("**💡 Insights**")
        st.markdown("Personalized recommendations")
    
    with col4:
        st.markdown("**🎯 Goals**")
        st.markdown("Set and track financial goals")
    
    # Navigation guide
    st.markdown("---")
    st.markdown("### 🚀 Next Steps")
    st.info("""
    **Ready to Explore?** Once you've uploaded your data, use the navigation menu to explore:
    
    • **📊 Dashboard:** Overview of your financial health  
    • **🤖 AI Advisor:** Chat with your personal finance AI  
    • **📈 Analytics:** Detailed spending analysis  
    • **💡 Insights:** Personalized recommendations
    """)

def show_dashboard(analysis, health_score, df, viz):
    """Display the clean and organized dashboard"""
    
    # Clean header
    st.markdown('<h1 class="section-header">📊 Financial Dashboard</h1>', unsafe_allow_html=True)
    
    # Status banner
    score = health_score['total_score']
    grade = health_score['grade']
    if score >= 80:
        st.success("🎉 **Excellent financial health!** Keep up the great work!")
    elif score >= 60:
        st.info("📈 **Good financial health** with room for improvement")
    elif score >= 40:
        st.warning("⚠️ **Fair financial health** - let's work on improvements")
    else:
        st.error("🚨 **Poor financial health** - immediate action needed")
    
    # Key metrics - clean layout
    st.markdown("### 💰 Key Financial Metrics")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="💰 Total Income",
            value=f"${analysis['total_income']:,.0f}",
            delta=f"{analysis['savings_rate']:.1f}% savings rate"
        )
    
    with col2:
        st.metric(
            label="💸 Total Expenses",
            value=f"${analysis['total_expenses']:,.0f}",
            delta=f"${analysis['total_expenses']/6:,.0f} monthly avg"
        )
    
    with col3:
        st.metric(
            label="📈 Net Income",
            value=f"${analysis['net_income']:,.0f}",
            delta="Positive" if analysis['net_income'] > 0 else "Negative"
        )
    
    with col4:
        st.metric(
            label="🎯 Health Score",
            value=f"{score}/100",
            delta=f"Grade: {grade}"
        )
    
    # Charts section - clean and organized
    st.markdown("### 📊 Visual Analytics")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**🏷️ Spending by Category**")
        category_chart = viz.spending_by_category_chart(analysis['category_spending'])
        st.plotly_chart(category_chart, use_container_width=True)
    
    with col2:
        st.markdown("**📅 Monthly Spending Trend**")
        trend_chart = viz.monthly_spending_trend(analysis['monthly_spending'])
        st.plotly_chart(trend_chart, use_container_width=True)
    
    # Health score section
    st.markdown("### 🎯 Financial Health Analysis")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("**📊 Health Score Gauge**")
        gauge_chart = viz.financial_health_gauge(
            health_score['total_score'], 
            health_score['grade']
        )
        st.plotly_chart(gauge_chart, use_container_width=True)
    
    with col2:
        st.markdown("**📈 Score Details**")
        st.info(f"""
        **Current Score:** {score}/100  
        **Grade:** {grade}  
        **Status:** {"Excellent" if score >= 80 else "Good" if score >= 60 else "Fair" if score >= 40 else "Needs Improvement"}  
        **Period:** {analysis.get('date_range', {}).get('start', 'N/A')} to {analysis.get('date_range', {}).get('end', 'N/A')}
        """)
    
    # Health Score Factors Breakdown
    st.markdown('<h3 class="section-header">📋 Health Score Factors</h3>', unsafe_allow_html=True)
    
    for factor, data in health_score['factors'].items():
        factor_name = factor.replace('_', ' ').title()
        progress = data['score'] / data['max_score']
        progress_color = "#27ae60" if progress >= 0.8 else "#f39c12" if progress >= 0.6 else "#e74c3c"
        
        st.markdown(f'''
        <div class="info-box">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                <h4 style="margin: 0; color: #2c3e50;">{factor_name}</h4>
                <span style="font-weight: bold; color: {progress_color};">{data['score']}/{data['max_score']}</span>
            </div>
            <div style="background: #ecf0f1; border-radius: 10px; height: 8px; margin-bottom: 0.5rem;">
                <div style="background: {progress_color}; height: 8px; border-radius: 10px; width: {progress*100}%; transition: width 0.3s ease;"></div>
            </div>
            <p style="margin: 0; color: #7f8c8d; font-size: 0.9rem;">
                {"Excellent" if progress >= 0.8 else "Good" if progress >= 0.6 else "Needs Improvement"}
            </p>
        </div>
        ''', unsafe_allow_html=True)
    
    # Recommendations Section
    if health_score['recommendations']:
        st.markdown('<h3 class="section-header">💡 AI-Powered Recommendations</h3>', unsafe_allow_html=True)
        
        for i, rec in enumerate(health_score['recommendations'], 1):
            st.markdown(f'''
            <div class="info-box">
                <div style="display: flex; align-items: center; margin-bottom: 0.5rem;">
                    <span style="background: #667eea; color: white; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; font-weight: bold; margin-right: 1rem;">{i}</span>
                    <h4 style="margin: 0; color: #2c3e50;">Recommendation</h4>
                </div>
                <p style="margin: 0; color: #34495e; line-height: 1.5;">{rec}</p>
            </div>
            ''', unsafe_allow_html=True)

def show_ai_advisor(ai_engine, analysis):
    """Display the clean AI chat interface"""
    st.markdown('<h1 class="section-header">🤖 AI Financial Advisor</h1>', unsafe_allow_html=True)
    
    # Clean introduction
    st.info("💬 **Chat with Your AI Financial Advisor** - Ask me anything about your finances! I can help with budgeting, savings, investments, and more. I analyze your spending patterns and provide personalized, actionable advice.")
    
    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []
    
    # Chat container
    st.markdown('<div class="chat-container">', unsafe_allow_html=True)
    
    # Display chat history
    for message in st.session_state.messages:
        if message["role"] == "user":
            st.markdown(f'''
            <div class="user-message">
                <strong>You:</strong> {message["content"]}
            </div>
            ''', unsafe_allow_html=True)
        else:
            st.markdown(f'''
            <div class="ai-message">
                <strong>FinGenius:</strong> {message["content"]}
            </div>
            ''', unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Chat input
    if prompt := st.chat_input("Ask me about your finances..."):
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        # Display user message
        st.markdown(f'''
        <div class="user-message">
            <strong>You:</strong> {prompt}
        </div>
        ''', unsafe_allow_html=True)
        
        # Get AI response
        with st.spinner("🤖 FinGenius is thinking..."):
            response = ai_engine.chat_with_ai(prompt, analysis)
        
        # Display AI response
        st.markdown(f'''
        <div class="ai-message">
            <strong>FinGenius:</strong> {response}
        </div>
        ''', unsafe_allow_html=True)
        
        # Add AI response to chat history
        st.session_state.messages.append({"role": "assistant", "content": response})
    
    # Quick actions - clean layout
    st.markdown("### 🚀 Quick Actions")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("💡 How can I save more?"):
            with st.spinner("Analyzing..."):
                response = ai_engine.chat_with_ai("How can I save more money based on my current spending?", analysis)
            st.info(f"**FinGenius:** {response}")
    
    with col2:
        if st.button("📊 Explain my spending"):
            with st.spinner("Analyzing..."):
                response = ai_engine.chat_with_ai("Can you explain my spending patterns and what they mean?", analysis)
            st.info(f"**FinGenius:** {response}")
    
    with col3:
        if st.button("🎯 Set a budget"):
            with st.spinner("Creating budget..."):
                response = ai_engine.chat_with_ai("Help me create a realistic budget based on my income and spending", analysis)
            st.info(f"**FinGenius:** {response}")

def show_analytics(df, analysis, viz):
    """Display clean detailed analytics"""
    st.markdown('<h1 class="section-header">📈 Detailed Analytics</h1>', unsafe_allow_html=True)
    
    # Clean overview
    st.info("📊 **Comprehensive Financial Analysis** - Dive deep into your spending patterns, merchant analysis, and financial trends with interactive visualizations and detailed breakdowns.")
    
    # Clean analytics layout
    st.markdown("### 🏪 Spending Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**🏪 Top Spending Locations**")
        merchants_chart = viz.top_merchants_chart(analysis['top_merchants'])
        st.plotly_chart(merchants_chart, use_container_width=True)
    
    with col2:
        st.markdown("**💰 Income vs Expenses**")
        income_expenses_chart = viz.income_vs_expenses_chart(analysis)
        st.plotly_chart(income_expenses_chart, use_container_width=True)
    
    # Spending patterns
    st.markdown("### 🕐 Spending Patterns")
    st.markdown("**📅 Weekly Spending Heatmap**")
    heatmap = viz.spending_pattern_heatmap(df)
    st.plotly_chart(heatmap, use_container_width=True)
    
    # Category breakdown - clean format
    st.markdown("### 📋 Category Breakdown")
    
    # Create category breakdown
    category_data = []
    for cat, amt in analysis['category_spending'].items():
        percentage = amt/analysis['total_expenses']*100
        category_data.append({
            "Category": cat,
            "Amount": f"${amt:,.2f}",
            "Percentage": f"{percentage:.1f}%",
            "Status": "High" if percentage > 20 else "Medium" if percentage > 10 else "Low"
        })
    
    category_df = pd.DataFrame(category_data)
    
    # Display clean table
    st.dataframe(
        category_df,
        use_container_width=True,
        hide_index=True
    )

def show_insights(ai_engine, analysis, health_score):
    """Display clean AI-generated insights"""
    st.markdown('<h1 class="section-header">💡 AI-Powered Insights</h1>', unsafe_allow_html=True)
    
    # Generate budget recommendations
    budget_recs = ai_engine.generate_budget_recommendations(analysis)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Budget Recommendations")
        st.write("Based on the 50/30/20 rule:")
        
        for category, data in budget_recs['recommended_budgets'].items():
            current = budget_recs['current_spending'][category]
            adjustment = budget_recs['adjustments_needed'][category]
            
            st.write(f"**{category.title()}:**")
            st.write(f"- Recommended: ${data:,.2f}")
            st.write(f"- Current: ${current:,.2f}")
            st.write(f"- Adjustment: ${adjustment:,.2f}")
            st.write("---")
    
    with col2:
        st.subheader("🎯 Goal Setting")
        
        # Interactive goal setting
        goal_type = st.selectbox("What's your financial goal?", [
            "Build Emergency Fund",
            "Save for Vacation",
            "Pay Off Debt",
            "Increase Savings Rate",
            "Reduce Spending"
        ])
        
        if st.button("Get Personalized Plan"):
            with st.spinner("Creating your plan..."):
                prompt = f"I want to {goal_type.lower()}. Help me create a specific, actionable plan based on my current financial situation."
                response = ai_engine.chat_with_ai(prompt, analysis)
                st.success(response)
    
    # Financial education
    st.subheader("📚 Financial Education")
    education_topics = [
        "What is compound interest?",
        "How to build an emergency fund",
        "Understanding credit scores",
        "50/30/20 budgeting rule",
        "Debt-to-income ratio explained"
    ]
    
    selected_topic = st.selectbox("Learn about:", education_topics)
    if st.button("Explain"):
        with st.spinner("Preparing explanation..."):
            response = ai_engine.chat_with_ai(f"Explain {selected_topic.lower()}", analysis)
            st.info(response)

def show_settings():
    """Display clean settings page"""
    st.markdown('<h1 class="section-header">⚙️ Settings & Configuration</h1>', unsafe_allow_html=True)
    
    # File Upload Section
    st.markdown("### 📁 Upload Your Spending Data")
    st.info("📊 **Import Your Financial Data** - Upload your own transaction data in CSV format to get personalized insights! FinGenius will analyze your real spending patterns and provide tailored recommendations.")
    
    # Clean file uploader
    uploaded_file = st.file_uploader(
        "Choose a CSV file",
        type=['csv'],
        help="Upload a CSV file with columns: date, description, category, amount, merchant, type"
    )
    
    if uploaded_file is not None:
        try:
            # Read the uploaded file
            df_uploaded = pd.read_csv(uploaded_file)
            
            # Validate columns
            required_columns = ['date', 'description', 'category', 'amount', 'merchant', 'type']
            if all(col in df_uploaded.columns for col in required_columns):
                # Convert date column
                df_uploaded['date'] = pd.to_datetime(df_uploaded['date'])
                
                st.success(f"✅ Successfully uploaded {len(df_uploaded)} transactions!")
                
                # Store in session state
                st.session_state.uploaded_data = df_uploaded
                st.session_state.use_uploaded_data = True
                
                # Show preview
                st.subheader("📊 Data Preview")
                st.dataframe(df_uploaded.head(10))
                
                # Quick analysis button
                if st.button("🚀 Analyze My Data"):
                    st.session_state.analyze_uploaded = True
                    st.rerun()
                    
            else:
                st.error("❌ CSV file must have these columns: date, description, category, amount, merchant, type")
                st.info("💡 Here's the expected format:")
                
                # Show example format
                example_data = {
                    'date': ['2024-01-15', '2024-01-16', '2024-01-17'],
                    'description': ['Grocery Shopping', 'Gas Station', 'Salary Deposit'],
                    'category': ['Groceries', 'Gas', 'Income'],
                    'amount': [150.00, 45.00, 3000.00],
                    'merchant': ['Kroger', 'Shell', 'Employer'],
                    'type': ['debit', 'debit', 'credit']
                }
                example_df = pd.DataFrame(example_data)
                st.dataframe(example_df)
                
        except Exception as e:
            st.error(f"❌ Error reading file: {str(e)}")
    
    # Toggle between sample and uploaded data
    st.subheader("🔄 Data Source")
    data_source = st.radio(
        "Choose data source:",
        ["📊 Sample Demo Data", "📁 My Uploaded Data"],
        index=0 if not st.session_state.get('use_uploaded_data', False) else 1
    )
    
    if data_source == "📊 Sample Demo Data":
        st.session_state.use_uploaded_data = False
        st.info("Using sample data with 366 realistic transactions")
    else:
        if st.session_state.get('uploaded_data') is not None:
            st.info(f"Using your uploaded data with {len(st.session_state.uploaded_data)} transactions")
        else:
            st.warning("No uploaded data available. Please upload a CSV file first.")
    
    # API Configuration
    st.subheader("🔑 API Configuration")
    st.write("Configure your AI provider:")
    
    ai_provider = st.selectbox("AI Provider", ["OpenAI GPT", "Google Gemini"])
    
    if ai_provider == "OpenAI GPT":
        st.info("Make sure to set your OPENAI_API_KEY in the .env file")
    else:
        st.info("Make sure to set your GOOGLE_API_KEY in the .env file")
    
    # Data Management
    st.subheader("📁 Data Management")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🔄 Regenerate Sample Data"):
            with st.spinner("Generating new sample data..."):
                generator = TransactionDataGenerator()
                df = generator.generate_transactions(months=6, transactions_per_month=60)
                df.to_csv('sample_transactions.csv', index=False)
                st.success("Sample data regenerated!")
    
    with col2:
        if st.button("📊 Download Sample Data"):
            if os.path.exists('sample_upload.csv'):
                with open('sample_upload.csv', 'r') as f:
                    st.download_button(
                        label="Download Sample CSV",
                        data=f.read(),
                        file_name="sample_transactions.csv",
                        mime="text/csv",
                        help="Download this sample file to test the upload feature"
                    )
            else:
                st.warning("Sample file not available")
    
    # Export current analysis data
    st.subheader("📤 Export Analysis")
    if st.button("📈 Export My Financial Analysis"):
        # Create a summary report
        report_data = {
            'Metric': ['Total Income', 'Total Expenses', 'Net Income', 'Savings Rate', 'Financial Health Score'],
            'Value': [
                f"${analysis.get('total_income', 0):,.2f}",
                f"${analysis.get('total_expenses', 0):,.2f}",
                f"${analysis.get('net_income', 0):,.2f}",
                f"{analysis.get('savings_rate', 0):.1f}%",
                f"{health_score.get('total_score', 0)}/100 ({health_score.get('grade', 'N/A')})"
            ]
        }
        report_df = pd.DataFrame(report_data)
        csv_report = report_df.to_csv(index=False)
        
        st.download_button(
            label="📊 Download Financial Report",
            data=csv_report,
            file_name="financial_analysis_report.csv",
            mime="text/csv"
        )
    
    # About
    st.subheader("ℹ️ About FinGenius")
    st.write("""
    **FinGenius** is an AI-powered personal finance advisor that helps you:
    - Understand your spending patterns
    - Get personalized financial advice
    - Track your financial health
    - Set and achieve financial goals
    
    Built with:
    - Python & Streamlit
    - OpenAI GPT / Google Gemini
    - ChromaDB for RAG
    - Plotly for visualizations
    """)

if __name__ == "__main__":
    main()
