# FinGenius - AI-Powered Personal Finance Advisor

## 🚀 **Hackathon Project Overview**

FinGenius is an intelligent personal finance advisor that analyzes transaction data and provides personalized AI-powered insights through a conversational interface.

### ✨ **Key Features**
- 📁 **Upload Real Data** - CSV file upload with validation
- 🤖 **AI Financial Advisor** - Conversational AI for financial advice
- 📊 **Advanced Analytics** - Interactive charts and spending analysis
- 💡 **Personalized Insights** - AI-generated recommendations
- 🎯 **Financial Health Score** - Comprehensive financial wellness assessment

### 🛠 **Technology Stack**
- **Frontend:** Streamlit (Python)
- **AI:** OpenAI GPT / Google Gemini
- **Analytics:** Pandas, Plotly, NumPy
- **Vector DB:** ChromaDB for RAG
- **Visualization:** Interactive charts and graphs

## 🚀 **Quick Start**

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Set Up API Key
Create `.env` file:
```env
OPENAI_API_KEY=your_openai_api_key_here
```

### 3. Run the App
```bash
streamlit run app.py
```

### 4. Demo Mode (No API Keys)
```bash
streamlit run demo_mode.py
```

## 📁 **Project Structure**
```
├── app.py                 # Main Streamlit application
├── ai_engine.py          # AI logic and RAG implementation
├── visualizations.py     # Chart and graph functions
├── data_generator.py     # Sample data generation
├── config.py            # Configuration settings
├── demo_mode.py         # Demo version (no API keys needed)
├── requirements.txt     # Python dependencies
├── sample_upload.csv    # Sample data for testing
└── DEMO_GUIDE.md       # Presentation guide
```

## 🎯 **For Hackathon Demo**
See `DEMO_GUIDE.md` for complete presentation instructions and demo script.

## 🏆 **Hackathon Ready!**
- ✅ Professional UI/UX
- ✅ Real data processing
- ✅ AI-powered insights
- ✅ Interactive visualizations
- ✅ Upload-first approach
- ✅ Production-ready architecture